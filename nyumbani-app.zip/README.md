
# Nyumbani App

A modern real estate platform built with React + Tailwind CSS.

## Features
- 🔍 Search and filter listings
- 🏘️ Post, view, and manage properties
- 💬 Messaging system
- 💳 M-Pesa simulation modal
- 🌍 Interactive map via Leaflet
- 🛠 Admin dashboard
- 🖼 Gallery + YouTube video tours
- 🌐 English/Swahili language toggle

## Getting Started
```bash
npm install
npm run dev
```

## Deploy on Vercel
1. Push to GitHub
2. Import into https://vercel.com
3. Set Framework = Vite
4. Deploy 🚀
